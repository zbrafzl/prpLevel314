﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;


namespace Prp.Data
{
    public class ActionDAL : PrpDBConnect
    {
        public ApplicantAction GetById(int applicantId, int typeId)
        {
            ApplicantAction obj = new ApplicantAction();
            try
            {
                var objt = db.spApplicantActionGetByApplicantId(applicantId, typeId).FirstOrDefault();
                obj = MapResignation.ToEntity(objt);
            }
            catch (Exception)
            {
                obj = new ApplicantAction();
            }
            return obj;
        }
        public Message AddUpdateLeave(ApplicantLeaveAction obj)
        {
            SqlCommand cmd = new SqlCommand
            {
                CommandType = CommandType.StoredProcedure,
                CommandText = "[dbo].[spLeaveAddUpdate]"
            };
            cmd.Parameters.AddWithValue("@actionId", obj.actionId);
            cmd.Parameters.AddWithValue("@applicantId", obj.applicantId);
            cmd.Parameters.AddWithValue("@image", obj.image);
            cmd.Parameters.AddWithValue("@imageAffidavit", obj.imageAffidavit);
            cmd.Parameters.AddWithValue("@imageMedical", obj.imageMedical);
            cmd.Parameters.AddWithValue("@imageMaternity", obj.imageMaternity);
            cmd.Parameters.AddWithValue("@imagePGAC", obj.imagePGAC);
            cmd.Parameters.AddWithValue("@imageForwarding", obj.imageForwarding);
            cmd.Parameters.AddWithValue("@imageSurety", obj.imageSurety);
            cmd.Parameters.AddWithValue("@ddlDoxTaken", obj.ddlDoxTaken);
            cmd.Parameters.AddWithValue("@typeId", obj.typeId);
            cmd.Parameters.AddWithValue("@categoryId", obj.categoryId);
            cmd.Parameters.AddWithValue("@startDate", obj.startDate);   
            cmd.Parameters.AddWithValue("@endDate", obj.endDate);
            cmd.Parameters.AddWithValue("@isDocsCollected", obj.isDocsCollected);
            cmd.Parameters.AddWithValue("@remarks", obj.remarks);
            cmd.Parameters.AddWithValue("@statusId", obj.statusId);
            cmd.Parameters.AddWithValue("@adminId", obj.adminId);
            cmd.Parameters.AddWithValue("@imageAttorney", obj.imageAttorney);
            cmd.Parameters.AddWithValue("@imageVisa", obj.imageVisa);
            cmd.Parameters.AddWithValue("@imagePurpose", obj.imagePurpose);
            cmd.Parameters.AddWithValue("@edd", obj.edd);
            return PrpDbADO.FillDataTableMessage(cmd);
        }

        public Message AddUpdateExtension(ApplicantExtensionAction obj)
        {
            SqlCommand cmd = new SqlCommand
            {
                CommandType = CommandType.StoredProcedure,
                CommandText = "[dbo].[spExtensionAddUpdate]"
            };
            cmd.Parameters.AddWithValue("@applicantId", obj.applicantId);
            cmd.Parameters.AddWithValue("@imageApplicantion", obj.imageApplication);
            cmd.Parameters.AddWithValue("@imagePER", obj.imagePER);
            cmd.Parameters.AddWithValue("@imageNOC", obj.imageNOC);
            cmd.Parameters.AddWithValue("@imagePMDC", obj.imagePMDC);
            cmd.Parameters.AddWithValue("@imageExtensionOrder", obj.imageExtensionOrder);
            cmd.Parameters.AddWithValue("@imageJoiningOrder", obj.imageJoiningOrder);
            cmd.Parameters.AddWithValue("@imageDoc1", obj.imageDoc1);
            cmd.Parameters.AddWithValue("@imageDoc2", obj.imageDoc2);
            cmd.Parameters.AddWithValue("@approvalBySupervisor", obj.approvalBySupervisor);
            cmd.Parameters.AddWithValue("@startDate", obj.startDate);
            cmd.Parameters.AddWithValue("@endDate", obj.endDate);
            cmd.Parameters.AddWithValue("@remarks", "");
            cmd.Parameters.AddWithValue("@adminId", obj.adminId);
            cmd.Parameters.AddWithValue("@noMonths", obj.noOfMonths);
            cmd.Parameters.AddWithValue("@imageInductionOrder", obj.imageInductionOrder);
            cmd.Parameters.AddWithValue("@rtmcUhsNo", obj.rtmcUhsNo);
            cmd.Parameters.AddWithValue("@imageTothc", obj.imageTothc);
            cmd.Parameters.AddWithValue("@imageJoat", obj.imageJoat);
            return PrpDbADO.FillDataTableMessage(cmd);
        }

        public Message AddUpdateExtensionApproval(ApplicantExtensionAction obj)
        {
            SqlCommand cmd = new SqlCommand
            {
                CommandType = CommandType.StoredProcedure,
                CommandText = "[dbo].[spExtensionApprovalAddUpdate]"
            };
            cmd.Parameters.AddWithValue("@actionId", obj.actionId);
            cmd.Parameters.AddWithValue("@applicantId", obj.applicantId);
            cmd.Parameters.AddWithValue("@applicantLeaveId", obj.applicantExtensionId);
            cmd.Parameters.AddWithValue("@remarks", obj.remarks);
            cmd.Parameters.AddWithValue("@adminId", obj.adminId);
            return PrpDbADO.FillDataTableMessage(cmd);
        }

        public Message AddUpdateLeaveApproval(ApplicantLeaveAction obj)
        {
            SqlCommand cmd = new SqlCommand
            {
                CommandType = CommandType.StoredProcedure,
                CommandText = "[dbo].[spLeaveApprovalAddUpdate]"
            };
            cmd.Parameters.AddWithValue("@actionId", obj.actionId);
            cmd.Parameters.AddWithValue("@applicantId", obj.applicantId);
            cmd.Parameters.AddWithValue("@applicantLeaveId", obj.applicantLeaveId);
            cmd.Parameters.AddWithValue("@remarks", obj.remarks);
            cmd.Parameters.AddWithValue("@adminId", obj.adminId);
            return PrpDbADO.FillDataTableMessage(cmd);
        }
        public Message AddUpdate(ApplicantAction obj)
        {
            SqlCommand cmd = new SqlCommand
            {
                CommandType = CommandType.StoredProcedure,
                CommandText = "[dbo].[spActionAddUpdate]"
            };
            cmd.Parameters.AddWithValue("@actionId", obj.actionId);
            cmd.Parameters.AddWithValue("@applicantId", obj.applicantId);
            cmd.Parameters.AddWithValue("@specialityJobId", obj.specialityJobId);
            cmd.Parameters.AddWithValue("@image", obj.image);
            cmd.Parameters.AddWithValue("@typeId", obj.typeId);
            cmd.Parameters.AddWithValue("@categoryId", obj.categoryId);
            cmd.Parameters.AddWithValue("@startDate", obj.startDate);
            cmd.Parameters.AddWithValue("@endDate", obj.endDate);
            cmd.Parameters.AddWithValue("@isDocsCollected", obj.isDocsCollected);
            cmd.Parameters.AddWithValue("@remarks", obj.remarks);
            cmd.Parameters.AddWithValue("@statusId", obj.statusId);
            cmd.Parameters.AddWithValue("@adminId", obj.adminId);
            return PrpDbADO.FillDataTableMessage(cmd);
        }

        public ApplicantLeaveAction getLeaveData(int applicantId, int applicantLeaveId)
        {
            ApplicantLeaveAction leaveData = new ApplicantLeaveAction();
            SqlCommand cmd = new SqlCommand
            {
                CommandType = CommandType.StoredProcedure,
                CommandText = "[dbo].[spGetLeaveData]"
            };
            SqlConnection con = new SqlConnection();
            con = new SqlConnection(PrpDbConnectADO.Conn);
            cmd.Parameters.AddWithValue("@applicantId", applicantId);
            cmd.Parameters.AddWithValue("@applicantLeaveId", applicantLeaveId);
            DataTable dt = new DataTable();
            cmd.Connection = con;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            try {
                sda.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    DataRow dr = dt.Rows[0];
                    leaveData.applicantId = Convert.ToInt32(dr[1]);
                    leaveData.typeId = Convert.ToInt32(dr[2]);
                    leaveData.startDate = Convert.ToDateTime(dr[3]);
                    leaveData.endDate = Convert.ToDateTime(dr[4]);
                    leaveData.image = dr[5].TooString();
                    leaveData.imageAffidavit = dr[6].TooString();
                    leaveData.dateRequested = Convert.ToDateTime(dr[7]);
                    leaveData.remarksRequested = dr[8].TooString();
                    leaveData.dateApproved = dr[9].TooString().TooDate();
                    leaveData.approvalRemarks = dr[10].TooString();
                    leaveData.noOfDays = dr[11].TooInt();
                    leaveData.approvedBy = dr[12].TooInt();
                    leaveData.requestedBy = dr[13].TooInt();
                    leaveData.approvalStatus = dr[14].TooInt();
                    leaveData.imageMedical = dr[15].TooString();
                    leaveData.imageMaternity = dr[16].TooString();
                    leaveData.imagePGAC = dr[17].TooString();
                    leaveData.ddlDoxTaken = dr[18].TooInt();
                    leaveData.imageForwarding = dr[19].TooString();
                    leaveData.imageSurety = dr[20].TooString();
                    leaveData.imageAttorney = dr[21].TooString();
                    leaveData.imageVisa = dr[22].TooString();
                    leaveData.imagePurpose = dr[23].TooString();
                    leaveData.edd = Convert.ToDateTime(dr[24]);
                    leaveData.requestedByName = dr[25].TooString();
                    leaveData.typeName = dr[26].TooString();
                    leaveData.approver = dr[27].TooString();
                }
            }
            catch (Exception ex)
            { 
            
            }
            
            return leaveData;
        }

        public List<ApplicantLeaveAction> getLeaveDataList(int applicantId)
        {
            List<ApplicantLeaveAction> leavesList = new List<ApplicantLeaveAction>();
            
            SqlCommand cmd = new SqlCommand
            {
                CommandType = CommandType.StoredProcedure,
                CommandText = "[dbo].[spGetLeaveData]"
            };
            SqlConnection con = new SqlConnection();
            con = new SqlConnection(PrpDbConnectADO.Conn);
            cmd.Parameters.AddWithValue("@applicantId", applicantId);
            //cmd.Parameters.AddWithValue("@applicantLeaveId", 0);
            DataTable dt = new DataTable();
            cmd.Connection = con;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            try
            {
                sda.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        ApplicantLeaveAction leaveData = new ApplicantLeaveAction();
                        leaveData.applicantId = Convert.ToInt32(dr[1]);
                        leaveData.typeId = Convert.ToInt32(dr[2]);
                        leaveData.startDate = Convert.ToDateTime(dr[3]);
                        leaveData.endDate = Convert.ToDateTime(dr[4]);
                        leaveData.image = dr[5].TooString();
                        leaveData.imageAffidavit = dr[6].TooString();
                        leaveData.dateRequested = Convert.ToDateTime(dr[7]);
                        leaveData.remarksRequested = dr[8].TooString();
                        leaveData.dateApproved = dr[9].TooString().TooDate();
                        leaveData.approvalRemarks = dr[10].TooString();
                        leaveData.noOfDays = dr[11].TooInt();
                        leaveData.approvedBy = dr[12].TooInt();
                        leaveData.requestedBy = dr[13].TooInt();
                        leaveData.approvalStatus = dr[14].TooInt();
                        leaveData.imageMedical = dr[15].TooString();
                        leaveData.imageMaternity = dr[16].TooString();
                        leaveData.imagePGAC = dr[17].TooString();
                        leaveData.ddlDoxTaken = dr[18].TooInt();
                        leaveData.imageForwarding = dr[19].TooString();
                        leaveData.imageSurety = dr[20].TooString();
                        leaveData.imageAttorney = dr[21].TooString();
                        leaveData.imageVisa = dr[22].TooString();
                        leaveData.imagePurpose = dr[23].TooString();
                        try
                        {
                            leaveData.edd = Convert.ToDateTime(dr[24]);
                        }
                        catch (Exception ex)
                        {
                            leaveData.edd = null;
                        }
                        //leaveData.edd = Convert.ToDateTime(dr[24]);
                        leaveData.requestedByName = dr[25].TooString();
                        leaveData.typeName = dr[26].TooString();
                        leaveData.approver = dr[27].TooString();
                        leavesList.Add(leaveData);
                    }
                }
            }
            catch (Exception ex)
            {

            }

            return leavesList;
        }
        public ApplicantExtensionAction getExtensionData(int applicantId, int applicantLeaveId)
        {
            ApplicantExtensionAction leaveData = new ApplicantExtensionAction();
            SqlCommand cmd = new SqlCommand
            {
                CommandType = CommandType.StoredProcedure,
                CommandText = "[dbo].[spGetExtensionData]"
            };
            SqlConnection con = new SqlConnection();
            con = new SqlConnection(PrpDbConnectADO.Conn);
            cmd.Parameters.AddWithValue("@applicantId", applicantId);
            cmd.Parameters.AddWithValue("@applicantLeaveId", applicantLeaveId);
            DataTable dt = new DataTable();
            cmd.Connection = con;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            try
            {
                sda.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    DataRow dr = dt.Rows[0];
                    int i = 0;
                    leaveData.applicantId = Convert.ToInt32(dr[++i]);
                    leaveData.startDate = Convert.ToDateTime(dr[++i]);
                    leaveData.endDate = Convert.ToDateTime(dr[++i]);
                    leaveData.noOfDays = dr[++i].TooInt();
                    leaveData.noOfMonths = dr[++i].TooInt();
                    leaveData.approvalBySupervisor = dr[++i].TooInt();
                    leaveData.imageApplication = dr[++i].TooString();
                    leaveData.imagePER = dr[++i].TooString();
                    leaveData.imageNOC = dr[++i].TooString();
                    leaveData.imagePMDC = dr[++i].TooString();
                    leaveData.imageExtensionOrder = dr[++i].TooString();
                    leaveData.imageJoiningOrder = dr[++i].TooString();
                    leaveData.imageDoc1 = dr[++i].TooString();
                    leaveData.imageDoc2 = dr[++i].TooString();
                    leaveData.requestedBy = dr[++i].TooInt();
                    leaveData.dateRequested = Convert.ToDateTime(dr[++i]);
                    leaveData.remarksRequested = dr[++i].TooString();
                    leaveData.approvalStatus = dr[++i].TooInt();
                    leaveData.approvedBy = dr[++i].TooInt();
                    leaveData.dateApproved = dr[++i].TooString().TooDate();
                    leaveData.approvalRemarks = dr[++i].TooString();
                    leaveData.imageInductionOrder = dr[++i].TooString();
                    leaveData.rtmcUhsNo = dr[++i].TooString();
                    leaveData.imageTothc = dr[++i].TooString();
                    leaveData.imageJoat = dr[++i].TooString();

                    leaveData.approvalByNawaz = dr[++i].TooInt();
                    leaveData.approvalBySO = dr[++i].TooInt();
                    leaveData.approvalByDS = dr[++i].TooInt();
                    leaveData.approvalByAST = dr[++i].TooInt();
                    leaveData.approvalBySS = dr[++i].TooInt();
                    leaveData.approvalBySec = dr[++i].TooInt();

                    leaveData.remarksByNawaz = dr[++i].TooString();
                    leaveData.remarksBySO = dr[++i].TooString();
                    leaveData.remarksByDS = dr[++i].TooString();
                    leaveData.remarksByAST = dr[++i].TooString();
                    leaveData.remarksBySec = dr[++i].TooString();

                    leaveData.imageApplicationRemarks = dr[++i].TooString();
                    leaveData.imagePERRemarks = dr[++i].TooString();
                    leaveData.imageNOCRemarks = dr[++i].TooString();
                    leaveData.imagePMDCRemarks = dr[++i].TooString();
                    leaveData.imageExtensionOrderRemarks = dr[++i].TooString();
                    leaveData.imageJoiningOrderRemarks = dr[++i].TooString();
                    leaveData.imageDoc1Remarks = dr[++i].TooString();
                    leaveData.imageDoc2Remarks = dr[++i].TooString();
                    leaveData.imageInductionOrderRemarks = dr[++i].TooString();
                    leaveData.rtmcUhsNoRemarks = dr[++i].TooString();
                    leaveData.imageTothcRemarks = dr[++i].TooString();
                    leaveData.imageJoatRemarks = dr[++i].TooString();

                    leaveData.imageApplicationValidity = dr[++i].TooBoolean();
                    leaveData.imagePERValidity = dr[++i].TooBoolean();
                    leaveData.imageNOCValidity = dr[++i].TooBoolean();
                    leaveData.imagePMDCValidity = dr[++i].TooBoolean();
                    leaveData.imageExtensionOrderValidity = dr[++i].TooBoolean();
                    leaveData.imageJoiningOrderValidity = dr[++i].TooBoolean();
                    leaveData.imageDoc1Validity = dr[++i].TooBoolean();
                    leaveData.imageDoc2Validity = dr[++i].TooBoolean();
                    leaveData.imageInductionOrderValidity = dr[++i].TooBoolean();
                    leaveData.rtmcUhsNoValidity = dr[++i].TooBoolean();
                    leaveData.imageTothcValidity = dr[++i].TooBoolean();
                    leaveData.imageJoatValidity = dr[++i].TooBoolean();

                    leaveData.forwardedTo = dr[++i].TooInt();

                    leaveData.requestedByName = dr[++i].TooString();
                    leaveData.approver = dr[++i].TooString();
                }
            }
            catch (Exception ex)
            {

            }

            return leaveData;
        }
        public List<ApplicantExtensionAction> getExtensionDataList(int applicantId)
        {
            List<ApplicantExtensionAction> leavesList = new List<ApplicantExtensionAction>();

            SqlCommand cmd = new SqlCommand
            {
                CommandType = CommandType.StoredProcedure,
                CommandText = "[dbo].[spGetExtensionData]"
            };
            SqlConnection con = new SqlConnection();
            con = new SqlConnection(PrpDbConnectADO.Conn);
            cmd.Parameters.AddWithValue("@applicantId", applicantId);
            //cmd.Parameters.AddWithValue("@applicantLeaveId", 0);
            DataTable dt = new DataTable();
            cmd.Connection = con;
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            try
            {
                sda.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        ApplicantExtensionAction leaveData = new ApplicantExtensionAction();
                        int i = 0;
                        leaveData.applicantId = Convert.ToInt32(dr[++i]);
                        leaveData.startDate = Convert.ToDateTime(dr[++i]);
                        leaveData.endDate = Convert.ToDateTime(dr[++i]);
                        leaveData.noOfDays = dr[++i].TooInt();
                        leaveData.noOfMonths = dr[++i].TooInt();
                        leaveData.approvalBySupervisor = dr[++i].TooInt();
                        leaveData.imageApplication = dr[++i].TooString();
                        leaveData.imagePER = dr[++i].TooString();
                        leaveData.imageNOC = dr[++i].TooString();
                        leaveData.imagePMDC = dr[++i].TooString();
                        leaveData.imageExtensionOrder = dr[++i].TooString();
                        leaveData.imageJoiningOrder = dr[++i].TooString();
                        leaveData.imageDoc1 = dr[++i].TooString();
                        leaveData.imageDoc2 = dr[++i].TooString();
                        leaveData.requestedBy = dr[++i].TooInt();
                        leaveData.dateRequested = Convert.ToDateTime(dr[++i]);
                        leaveData.remarksRequested = dr[++i].TooString();
                        leaveData.approvalStatus = dr[++i].TooInt();
                        leaveData.approvedBy = dr[++i].TooInt();
                        leaveData.dateApproved = dr[++i].TooString().TooDate();
                        leaveData.approvalRemarks = dr[++i].TooString();
                        leaveData.imageInductionOrder = dr[++i].TooString();
                        leaveData.rtmcUhsNo = dr[++i].TooString();
                        leaveData.imageTothc = dr[++i].TooString();
                        leaveData.imageJoat = dr[++i].TooString();

                        leaveData.approvalByNawaz = dr[++i].TooInt();
                        leaveData.approvalBySO = dr[++i].TooInt();
                        leaveData.approvalByDS = dr[++i].TooInt();
                        leaveData.approvalByAST = dr[++i].TooInt();
                        leaveData.approvalBySS = dr[++i].TooInt();
                        leaveData.approvalBySec = dr[++i].TooInt();

                        leaveData.remarksByNawaz = dr[++i].TooString();
                        leaveData.remarksBySO = dr[++i].TooString();
                        leaveData.remarksByDS = dr[++i].TooString();
                        leaveData.remarksByAST = dr[++i].TooString();
                        leaveData.remarksBySec = dr[++i].TooString();

                        leaveData.imageApplicationRemarks = dr[++i].TooString();
                        leaveData.imagePERRemarks = dr[++i].TooString();
                        leaveData.imageNOCRemarks = dr[++i].TooString();
                        leaveData.imagePMDCRemarks = dr[++i].TooString();
                        leaveData.imageExtensionOrderRemarks = dr[++i].TooString();
                        leaveData.imageJoiningOrderRemarks = dr[++i].TooString();
                        leaveData.imageDoc1Remarks = dr[++i].TooString();
                        leaveData.imageDoc2Remarks = dr[++i].TooString();
                        leaveData.imageInductionOrderRemarks = dr[++i].TooString();
                        leaveData.rtmcUhsNoRemarks = dr[++i].TooString();
                        leaveData.imageTothcRemarks = dr[++i].TooString();
                        leaveData.imageJoatRemarks = dr[++i].TooString();

                        leaveData.imageApplicationValidity = dr[++i].TooBoolean();
                        leaveData.imagePERValidity = dr[++i].TooBoolean();
                        leaveData.imageNOCValidity = dr[++i].TooBoolean();
                        leaveData.imagePMDCValidity = dr[++i].TooBoolean();
                        leaveData.imageExtensionOrderValidity = dr[++i].TooBoolean();
                        leaveData.imageJoiningOrderValidity = dr[++i].TooBoolean();
                        leaveData.imageDoc1Validity = dr[++i].TooBoolean();
                        leaveData.imageDoc2Validity = dr[++i].TooBoolean();
                        leaveData.imageInductionOrderValidity = dr[++i].TooBoolean();
                        leaveData.rtmcUhsNoValidity = dr[++i].TooBoolean();
                        leaveData.imageTothcValidity = dr[++i].TooBoolean();
                        leaveData.imageJoatValidity = dr[++i].TooBoolean();

                        leaveData.forwardedTo = dr[++i].TooInt();

                        leaveData.requestedByName = dr[++i].TooString();
                        leaveData.approver = dr[++i].TooString();
                        leavesList.Add(leaveData);
                    }
                }
            }
            catch (Exception ex)
            {

            }

            return leavesList;
        }
        public Message AddUpdateStatus(ApplicantAction obj)
        {
            SqlCommand cmd = new SqlCommand
            {
                CommandType = CommandType.StoredProcedure,
                CommandText = "[dbo].[spActionStatusAdd]"
            };
            cmd.Parameters.AddWithValue("@actionId", obj.actionId);
            cmd.Parameters.AddWithValue("@image", obj.image);
            cmd.Parameters.AddWithValue("@remarks", obj.remarks);
            cmd.Parameters.AddWithValue("@statusId", obj.statusId);
            cmd.Parameters.AddWithValue("@adminId", obj.adminId);
            return PrpDbADO.FillDataTableMessage(cmd);
        }
    }


}
