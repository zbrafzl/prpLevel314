﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Prp.Sln.Areas.nadmin.Controllers
{
    public class ConsentAdminController : Controller
    {
       
        public ActionResult ConsentSearch()
        {
            return View();
        }
    }
}